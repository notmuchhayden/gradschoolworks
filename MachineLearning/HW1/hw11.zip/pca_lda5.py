import numpy as np
import matplotlib.pyplot as plt
import h5py

# 데이터 로드 (h5py 사용)
with h5py.File('HW1_COIL20.mat', 'r') as mat_data:
    X = np.array(mat_data['X']).T
    Y = np.array(mat_data['Y']).ravel()

# PCA 구현
def pca(X, n_components):
    # 평균값 제거
    X_mean = np.mean(X, axis=0)
    X_centered = X - X_mean
    
    # 공분산 행렬 계산
    covariance_matrix = np.cov(X_centered, rowvar=False)
    
    # 고유값 및 고유벡터 계산
    eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)
    
    # 고유값의 내림차순 정렬
    sorted_indices = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[sorted_indices]
    eigenvectors = eigenvectors[:, sorted_indices]
    
    # 주요 성분 선택
    selected_vectors = eigenvectors[:, :n_components]
    reduced_data = np.dot(X_centered, selected_vectors)
    return reduced_data, selected_vectors

# LDA 구현
def lda(X, Y, n_components):
    # 클래스 별 평균 계산
    class_labels = np.unique(Y)
    overall_mean = np.mean(X, axis=0)
    S_W = np.zeros((X.shape[1], X.shape[1]))
    S_B = np.zeros((X.shape[1], X.shape[1]))
    
    for c in class_labels:
        X_c = X[Y == c]
        class_mean = np.mean(X_c, axis=0)
        S_W += np.dot((X_c - class_mean).T, (X_c - class_mean))
        n_c = X_c.shape[0]
        mean_diff = (class_mean - overall_mean).reshape(-1, 1)
        S_B += n_c * np.dot(mean_diff, mean_diff.T)
    
    # 고유값 및 고유벡터 계산
    eigenvalues, eigenvectors = np.linalg.eigh(np.linalg.inv(S_W).dot(S_B))
    
    # 고유값의 내림차순 정렬
    sorted_indices = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[sorted_indices]
    eigenvectors = eigenvectors[:, sorted_indices]
    
    # 주요 성분 선택
    selected_vectors = eigenvectors[:, :n_components]
    reduced_data = np.dot(X, selected_vectors)
    return reduced_data, selected_vectors

# PCA 적용 (2차원 축소)
X_pca, pca_components = pca(X, 2)

# PCA 적용 후 95% 정보 보존을 위한 축소
X_pca_highdim, _ = pca(X, int(X.shape[1] * 0.95))

# LDA 적용 (PCA 결과 기반, 2차원 축소)
X_lda, lda_components = lda(X_pca_highdim, Y, 2)

# 시각화 함수
def plot_2d(X, Y, title):
    plt.figure()
    for class_value in np.unique(Y):
        plt.scatter(X[Y == class_value, 0], X[Y == class_value, 1], label=f'Class {class_value}')
    plt.title(title)
    plt.legend()
    plt.show()

# PCA 결과 시각화
plot_2d(X_pca, Y, "PCA 2-Dim")

# LDA 결과 시각화
plot_2d(X_lda, Y, "LDA 2-Dim")
