import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import sqrtm, eig

# 데이터 생성
N = 100
m1 = np.array([0, 0])
s1 = np.array([[9, 0], [0, 1]])
m2 = np.array([0, 4])
s2 = np.array([[9, 0], [0, 1]])

X1 = np.random.randn(N, 2) @ sqrtm(s1) + m1  # 클래스1 데이터 생성
X2 = np.random.randn(N, 2) @ sqrtm(s2) + m2  # 클래스2 데이터 생성

# 데이터 시각화
plt.figure(1)
plt.plot(X2[:, 0], X2[:, 1], 'ro', label='Class 2')
plt.plot(X1[:, 0], X1[:, 1], '*', label='Class 1')
plt.axis([-10, 10, -5, 10])
plt.legend()

# PCA 분석
X = np.vstack((X1, X2))
M = np.mean(X, axis=0)
S = np.cov(X, rowvar=False)
V, D = eig(S)  # 고유값 분해

idx = np.argmax(D)  # 가장 큰 고유값의 인덱스 찾기
w1 = V[:, idx]  # 첫 번째 주성분 벡터

plt.figure(1)
plt.plot([M[0], M[0] + w1[0] * D.max()], [M[1], M[1] + w1[1] * D.max()], 'k-', linewidth=2)

# 주성분 벡터 방향으로 사영
YX1 = w1 @ X1.T
YX2 = w1 @ X2.T
pYX1 = np.outer(w1, YX1)
pYX2 = np.outer(w1, YX2)

plt.figure(2)
plt.plot(pYX1[0, :], pYX1[1, :] + M[1], '*')
plt.plot(pYX2[0, :], pYX2[1, :] + M[1], 'ro')
plt.axis([-10, 10, -5, 10])

# LDA 분석
m1_mean = np.mean(X1, axis=0)
m2_mean = np.mean(X2, axis=0)
Sw = N * np.cov(X1, rowvar=False) + N * np.cov(X2, rowvar=False)
Sb = np.outer(m1_mean - m2_mean, m1_mean - m2_mean)

V, D = eig(np.linalg.inv(Sw) @ Sb)
w = V[:, np.argsort(D)[-1]]  # 찾아진 벡터

plt.figure(1)
plt.plot([M[0], M[0] + w[0] * -8], [M[1], M[1] + w[1] * -8], 'g-', linewidth=2)

# LDA 방향으로 사영
YX1 = w @ X1.T
YX2 = w @ X2.T
pYX1 = np.outer(w, YX1)
pYX2 = np.outer(w, YX2)

plt.figure(2)
plt.plot(pYX1[0, :] + M[0], pYX1[1, :], '*')
plt.plot(pYX2[0, :] + M[0], pYX2[1, :], 'ro')
plt.show()
