import numpy as np
import h5py
import matplotlib.pyplot as plt

# 문제 1에서 작성한 PCA 구현
class PCA_Custom:
    def __init__(self, n_components):
        self.n_components = n_components
        self.mean = None
        self.components = None
    
    def fit_transform(self, X):
        self.mean = np.mean(X, axis=0)
        X_centered = X - self.mean
        cov_matrix = np.cov(X_centered, rowvar=False)
        eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
        
        idx = np.argsort(eigenvalues)[::-1]
        sorted_eigenvalues = eigenvalues[idx]
        sorted_eigenvectors = eigenvectors[:, idx]
        
        # 누적 분산을 이용한 차원 결정 (예: 95% 정보 유지)
        if isinstance(self.n_components, float) and 0 < self.n_components <= 1:
            cumulative_variance = np.cumsum(sorted_eigenvalues) / np.sum(sorted_eigenvalues)
            self.n_components = np.searchsorted(cumulative_variance, self.n_components) + 1
        
        self.components = sorted_eigenvectors[:, :self.n_components]
        return np.dot(X_centered, self.components)

# 문제 1에서 작성한 LDA 구현
class LDA_Custom:
    def __init__(self, n_components):
        self.n_components = n_components
        self.eigen_vectors = None
    
    def fit_transform(self, X, y):
        class_labels = np.unique(y)
        mean_overall = np.mean(X, axis=0)
        Sw = np.zeros((X.shape[1], X.shape[1]))
        Sb = np.zeros((X.shape[1], X.shape[1]))
        
        for label in class_labels:
            X_class = X[y == label]
            mean_class = np.mean(X_class, axis=0)
            Sw += np.cov(X_class, rowvar=False) * (X_class.shape[0] - 1)
            mean_diff = (mean_class - mean_overall).reshape(-1, 1)
            Sb += X_class.shape[0] * (mean_diff @ mean_diff.T)
        
        eig_vals, eig_vecs = np.linalg.eigh(np.linalg.pinv(Sw).dot(Sb))
        idx = np.argsort(eig_vals)[::-1]
        self.eigen_vectors = eig_vecs[:, idx[:self.n_components]]
        return np.dot(X, self.eigen_vectors)

# 데이터 로드 (h5py 사용)
with h5py.File('HW1_COIL20.mat', 'r') as mat_data:
    X = np.array(mat_data['X']).T  # 전치하여 형식 맞추기
    Y = np.array(mat_data['Y']).ravel()

# PCA를 통한 2차원 특징 추출
pca = PCA_Custom(n_components=2)
X_pca = pca.fit_transform(X)
X_pca[:, 0] *= -1  # 좌우 반전
X_pca[:, 1] *= -1  # 상하 반전

# PCA 결과 시각화
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
for label in np.unique(Y):
    plt.scatter(X_pca[Y == label, 0], X_pca[Y == label, 1], label=f'Class {label}', alpha=0.6)
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.title("PCA 2D Projection")

# PCA 95% 정보 보존 후 LDA 적용
pca_95 = PCA_Custom(n_components=0.95)
X_pca_95 = pca_95.fit_transform(X)
lda = LDA_Custom(n_components=2)
X_lda = lda.fit_transform(X_pca_95, Y)
X_lda[:, 0] *= -1  # LDA 결과 좌우 반전
X_lda[:, 1] *= -1  # LDA 결과 상하 반전

# LDA 결과 시각화
plt.subplot(1, 2, 2)
for label in np.unique(Y):
    plt.scatter(X_lda[Y == label, 0], X_lda[Y == label, 1], label=f'Class {label}', alpha=0.6)
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.title("LDA 2D Projection")

plt.show()
