import numpy as np
import h5py
import matplotlib.pyplot as plt


def pca(X):
    # 데이터 centering
    mean = np.mean(X, axis=0)
    X_centered = X - mean
    # 공분산 행렬 계산
    covariance_matrix = np.cov(X_centered, rowvar=False)
    # 고유값과 고유벡터 계산 (eigh 사용)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)
    # 고유값을 기준으로 내림차순 정렬
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvalues = eigenvalues[sorted_indices]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]
    return sorted_eigenvectors, sorted_eigenvalues, mean

def lda(X, y):
    # 클래스별 평균 계산
    class_labels = np.unique(y)
    means = [np.mean(X[y == label], axis=0) for label in class_labels]
    overall_mean = np.mean(X, axis=0)

    # 클래스 내 분산 행렬 계산
    Sw = np.zeros((X.shape[1], X.shape[1]))
    for label, mean in zip(class_labels, means):
        X_class = X[y == label]
        Sw += np.cov(X_class, rowvar=False) * (X_class.shape[0] - 1)

    # 클래스 간 분산 행렬 계산
    Sb = np.zeros((X.shape[1], X.shape[1]))
    for label, mean in zip(class_labels, means):
        n = np.sum(y == label)
        mean_diff = (mean - overall_mean).reshape(-1, 1)
        Sb += n * (mean_diff @ mean_diff.T)

    # 최적의 판별 벡터 계산 (eigh 사용, pinv 사용)
    eigenvalues, eigenvectors = np.linalg.eigh(np.linalg.pinv(Sw) @ Sb)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    lda_vectors = eigenvectors[:, sorted_indices].real  # 복소수 부분 제거
    return lda_vectors

# 데이터 로드 (h5py 사용)
with h5py.File('HW1_COIL20.mat', 'r') as mat_data:
    X = np.array(mat_data['X']).T  # 전치하여 형식 맞추기
    Y = np.array(mat_data['Y']).ravel()

# PCA를 통한 2차원 특징 추출
eigenvectors, eigenvalues, pca_mean = pca(X)
X_centered = X - pca_mean
X_pca = np.dot(X_centered, eigenvectors[:, :2])
X_pca[:, 0] *= -1  # 좌우 반전
X_pca[:, 1] *= -1  # 상하 반전

# PCA 결과 시각화
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
for label in np.unique(Y):
    plt.scatter(X_pca[Y == label, 0], X_pca[Y == label, 1], label=f'Class {label}', alpha=0.6)
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.title("PCA 2D Projection")

# PCA 95% 정보 보존 후 LDA 적용
eigenvectors, eigenvalues, pca_mean = pca(X)
cumulative_variance = np.cumsum(eigenvalues) / np.sum(eigenvalues)
n_components = np.searchsorted(cumulative_variance, 0.95) + 1
X_centered = X - pca_mean
X_pca_95 = np.dot(X_centered, eigenvectors[:, :n_components])

lda_vectors = lda(X_pca_95, Y)
X_lda = np.dot(X_pca_95, lda_vectors[:, :2])
X_lda[:, 0] *= -1  # LDA 결과 좌우 반전
#X_lda[:, 1] *= -1  # LDA 결과 상하 반전

# LDA 결과 시각화
plt.subplot(1, 2, 2)
for label in np.unique(Y):
    plt.scatter(X_lda[Y == label, 0], X_lda[Y == label, 1], label=f'Class {label}', alpha=0.6)
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.title("LDA 2D Projection")

plt.show()
