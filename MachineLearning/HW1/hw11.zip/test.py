import matplotlib
matplotlib.use('TkAgg')  # Or 'Qt5Agg', 'WXAgg', etc.
import matplotlib.pyplot as plt

 # ... (your plotting code) ...

plt.show()